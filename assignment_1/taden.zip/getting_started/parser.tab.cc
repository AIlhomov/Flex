// A Bison parser, made by GNU Bison 3.5.1.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.hh"


// Unqualified %code blocks.
#line 26 "parser.yy"

  #define YY_DECL yy::parser::symbol_type yylex()
  YY_DECL;
  
  Node* root;
  extern int yylineno;

#line 53 "parser.tab.cc"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif



// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

namespace yy {
#line 125 "parser.tab.cc"


  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser ()
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr)
#else

#endif
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[+state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state))
  {
    switch (that.type_get ())
    {
      case 48: // root
      case 49: // goal
      case 50: // classDeclaration
      case 51: // singleClassDeclaration
      case 52: // type
      case 53: // mainClass
      case 54: // varDeclaration
      case 55: // reqVarDeclaration
      case 56: // retSTMT
      case 57: // reqVarOrStmt
      case 58: // parameters
      case 59: // parameter_list
      case 60: // methodDeclaration
      case 61: // reqMethodDeclaration
      case 62: // statement
      case 63: // reqStatement
      case 64: // expression
      case 65: // dotExpTest
      case 66: // arguments
      case 67: // argument_list
      case 68: // identifier
      case 69: // factor
        value.YY_MOVE_OR_COPY< Node * > (YY_MOVE (that.value));
        break;

      case 3: // PLUSOP
      case 4: // MINUSOP
      case 5: // MULTOP
      case 6: // INT
      case 7: // LP
      case 8: // RP
      case 9: // AND
      case 10: // OR
      case 11: // LESS_THAN
      case 12: // MORE_THAN
      case 13: // EQUAL
      case 14: // TRUE
      case 15: // FALSE
      case 16: // THIS
      case 17: // NEW
      case 18: // LEFT_BRACKET
      case 19: // RIGHT_BRACKET
      case 20: // DOT
      case 21: // LENGTH
      case 22: // EXCLAMATION_MARK
      case 23: // LEFT_CURLY
      case 24: // RIGHT_CURLY
      case 25: // ASSIGN
      case 26: // MORE_THAN_EQUAL
      case 27: // LESS_THAN_EQUAL
      case 28: // UNDER_SCORE
      case 29: // BOOLEAN
      case 30: // CLASS
      case 31: // ELSE
      case 32: // IF
      case 33: // MAIN
      case 34: // PUBLIC
      case 35: // STRING
      case 36: // VOID
      case 37: // SYSTEM_OUT_PRINTLN
      case 38: // WHILE
      case 39: // EXTENDS
      case 40: // RETURN
      case 41: // STATIC
      case 42: // SEMI_COLON
      case 43: // COMMA
      case 44: // DIVIDE
      case 45: // IDENTIFIER
      case 46: // INTEGER_LITERAL
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s)
  {
    switch (that.type_get ())
    {
      case 48: // root
      case 49: // goal
      case 50: // classDeclaration
      case 51: // singleClassDeclaration
      case 52: // type
      case 53: // mainClass
      case 54: // varDeclaration
      case 55: // reqVarDeclaration
      case 56: // retSTMT
      case 57: // reqVarOrStmt
      case 58: // parameters
      case 59: // parameter_list
      case 60: // methodDeclaration
      case 61: // reqMethodDeclaration
      case 62: // statement
      case 63: // reqStatement
      case 64: // expression
      case 65: // dotExpTest
      case 66: // arguments
      case 67: // argument_list
      case 68: // identifier
      case 69: // factor
        value.move< Node * > (YY_MOVE (that.value));
        break;

      case 3: // PLUSOP
      case 4: // MINUSOP
      case 5: // MULTOP
      case 6: // INT
      case 7: // LP
      case 8: // RP
      case 9: // AND
      case 10: // OR
      case 11: // LESS_THAN
      case 12: // MORE_THAN
      case 13: // EQUAL
      case 14: // TRUE
      case 15: // FALSE
      case 16: // THIS
      case 17: // NEW
      case 18: // LEFT_BRACKET
      case 19: // RIGHT_BRACKET
      case 20: // DOT
      case 21: // LENGTH
      case 22: // EXCLAMATION_MARK
      case 23: // LEFT_CURLY
      case 24: // RIGHT_CURLY
      case 25: // ASSIGN
      case 26: // MORE_THAN_EQUAL
      case 27: // LESS_THAN_EQUAL
      case 28: // UNDER_SCORE
      case 29: // BOOLEAN
      case 30: // CLASS
      case 31: // ELSE
      case 32: // IF
      case 33: // MAIN
      case 34: // PUBLIC
      case 35: // STRING
      case 36: // VOID
      case 37: // SYSTEM_OUT_PRINTLN
      case 38: // WHILE
      case 39: // EXTENDS
      case 40: // RETURN
      case 41: // STATIC
      case 42: // SEMI_COLON
      case 43: // COMMA
      case 44: // DIVIDE
      case 45: // IDENTIFIER
      case 46: // INTEGER_LITERAL
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 48: // root
      case 49: // goal
      case 50: // classDeclaration
      case 51: // singleClassDeclaration
      case 52: // type
      case 53: // mainClass
      case 54: // varDeclaration
      case 55: // reqVarDeclaration
      case 56: // retSTMT
      case 57: // reqVarOrStmt
      case 58: // parameters
      case 59: // parameter_list
      case 60: // methodDeclaration
      case 61: // reqMethodDeclaration
      case 62: // statement
      case 63: // reqStatement
      case 64: // expression
      case 65: // dotExpTest
      case 66: // arguments
      case 67: // argument_list
      case 68: // identifier
      case 69: // factor
        value.copy< Node * > (that.value);
        break;

      case 3: // PLUSOP
      case 4: // MINUSOP
      case 5: // MULTOP
      case 6: // INT
      case 7: // LP
      case 8: // RP
      case 9: // AND
      case 10: // OR
      case 11: // LESS_THAN
      case 12: // MORE_THAN
      case 13: // EQUAL
      case 14: // TRUE
      case 15: // FALSE
      case 16: // THIS
      case 17: // NEW
      case 18: // LEFT_BRACKET
      case 19: // RIGHT_BRACKET
      case 20: // DOT
      case 21: // LENGTH
      case 22: // EXCLAMATION_MARK
      case 23: // LEFT_CURLY
      case 24: // RIGHT_CURLY
      case 25: // ASSIGN
      case 26: // MORE_THAN_EQUAL
      case 27: // LESS_THAN_EQUAL
      case 28: // UNDER_SCORE
      case 29: // BOOLEAN
      case 30: // CLASS
      case 31: // ELSE
      case 32: // IF
      case 33: // MAIN
      case 34: // PUBLIC
      case 35: // STRING
      case 36: // VOID
      case 37: // SYSTEM_OUT_PRINTLN
      case 38: // WHILE
      case 39: // EXTENDS
      case 40: // RETURN
      case 41: // STATIC
      case 42: // SEMI_COLON
      case 43: // COMMA
      case 44: // DIVIDE
      case 45: // IDENTIFIER
      case 46: // INTEGER_LITERAL
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 48: // root
      case 49: // goal
      case 50: // classDeclaration
      case 51: // singleClassDeclaration
      case 52: // type
      case 53: // mainClass
      case 54: // varDeclaration
      case 55: // reqVarDeclaration
      case 56: // retSTMT
      case 57: // reqVarOrStmt
      case 58: // parameters
      case 59: // parameter_list
      case 60: // methodDeclaration
      case 61: // reqMethodDeclaration
      case 62: // statement
      case 63: // reqStatement
      case 64: // expression
      case 65: // dotExpTest
      case 66: // arguments
      case 67: // argument_list
      case 68: // identifier
      case 69: // factor
        value.move< Node * > (that.value);
        break;

      case 3: // PLUSOP
      case 4: // MINUSOP
      case 5: // MULTOP
      case 6: // INT
      case 7: // LP
      case 8: // RP
      case 9: // AND
      case 10: // OR
      case 11: // LESS_THAN
      case 12: // MORE_THAN
      case 13: // EQUAL
      case 14: // TRUE
      case 15: // FALSE
      case 16: // THIS
      case 17: // NEW
      case 18: // LEFT_BRACKET
      case 19: // RIGHT_BRACKET
      case 20: // DOT
      case 21: // LENGTH
      case 22: // EXCLAMATION_MARK
      case 23: // LEFT_CURLY
      case 24: // RIGHT_CURLY
      case 25: // ASSIGN
      case 26: // MORE_THAN_EQUAL
      case 27: // LESS_THAN_EQUAL
      case 28: // UNDER_SCORE
      case 29: // BOOLEAN
      case 30: // CLASS
      case 31: // ELSE
      case 32: // IF
      case 33: // MAIN
      case 34: // PUBLIC
      case 35: // STRING
      case 36: // VOID
      case 37: // SYSTEM_OUT_PRINTLN
      case 38: // WHILE
      case 39: // EXTENDS
      case 40: // RETURN
      case 41: // STATIC
      case 42: // SEMI_COLON
      case 43: // COMMA
      case 44: // DIVIDE
      case 45: // IDENTIFIER
      case 46: // INTEGER_LITERAL
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " (";
    YYUSE (yytype);
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex ());
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 48: // root
      case 49: // goal
      case 50: // classDeclaration
      case 51: // singleClassDeclaration
      case 52: // type
      case 53: // mainClass
      case 54: // varDeclaration
      case 55: // reqVarDeclaration
      case 56: // retSTMT
      case 57: // reqVarOrStmt
      case 58: // parameters
      case 59: // parameter_list
      case 60: // methodDeclaration
      case 61: // reqMethodDeclaration
      case 62: // statement
      case 63: // reqStatement
      case 64: // expression
      case 65: // dotExpTest
      case 66: // arguments
      case 67: // argument_list
      case 68: // identifier
      case 69: // factor
        yylhs.value.emplace< Node * > ();
        break;

      case 3: // PLUSOP
      case 4: // MINUSOP
      case 5: // MULTOP
      case 6: // INT
      case 7: // LP
      case 8: // RP
      case 9: // AND
      case 10: // OR
      case 11: // LESS_THAN
      case 12: // MORE_THAN
      case 13: // EQUAL
      case 14: // TRUE
      case 15: // FALSE
      case 16: // THIS
      case 17: // NEW
      case 18: // LEFT_BRACKET
      case 19: // RIGHT_BRACKET
      case 20: // DOT
      case 21: // LENGTH
      case 22: // EXCLAMATION_MARK
      case 23: // LEFT_CURLY
      case 24: // RIGHT_CURLY
      case 25: // ASSIGN
      case 26: // MORE_THAN_EQUAL
      case 27: // LESS_THAN_EQUAL
      case 28: // UNDER_SCORE
      case 29: // BOOLEAN
      case 30: // CLASS
      case 31: // ELSE
      case 32: // IF
      case 33: // MAIN
      case 34: // PUBLIC
      case 35: // STRING
      case 36: // VOID
      case 37: // SYSTEM_OUT_PRINTLN
      case 38: // WHILE
      case 39: // EXTENDS
      case 40: // RETURN
      case 41: // STATIC
      case 42: // SEMI_COLON
      case 43: // COMMA
      case 44: // DIVIDE
      case 45: // IDENTIFIER
      case 46: // INTEGER_LITERAL
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }



      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 2:
#line 72 "parser.yy"
             {root = yystack_[0].value.as < Node * > (); }
#line 899 "parser.tab.cc"
    break;

  case 3:
#line 75 "parser.yy"
                                     { 
		yylhs.value.as < Node * > () = new Node("goal", "", yylineno); 
		yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
		yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
	}
#line 909 "parser.tab.cc"
    break;

  case 4:
#line 83 "parser.yy"
                                          { 
			yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > ();
			}
#line 917 "parser.tab.cc"
    break;

  case 5:
#line 91 "parser.yy"
                                                                       {
						yylhs.value.as < Node * > () = new Node("classDeclarations", "", yylineno);
						Node* classes =	new Node("classDeclaration", yystack_[4].value.as < Node * > ()->value , yylineno);
						
						classes->children.push_back(yystack_[4].value.as < Node * > ());
						classes->children.push_back(yystack_[2].value.as < Node * > ());
						classes->children.push_back(yystack_[1].value.as < Node * > ());

						yylhs.value.as < Node * > ()->children.push_back(classes);
					}
#line 932 "parser.tab.cc"
    break;

  case 6:
#line 104 "parser.yy"
                                                                         {
						yylhs.value.as < Node * > () = yystack_[6].value.as < Node * > (); // singleClassDeclaration
						//$$ = new Node("ClassDeclarationsHERERERERE", "", yylineno);

						Node* classes = new Node("classDeclaration", yystack_[4].value.as < Node * > ()->value, yylineno);

						classes->children.push_back(yystack_[4].value.as < Node * > ());
						classes->children.push_back(yystack_[2].value.as < Node * > ());
						classes->children.push_back(yystack_[1].value.as < Node * > ());

						yylhs.value.as < Node * > ()->children.push_back(classes);
					}
#line 949 "parser.tab.cc"
    break;

  case 7:
#line 125 "parser.yy"
                                     { yylhs.value.as < Node * > () = new Node("INT LB RB", "", yylineno); }
#line 955 "parser.tab.cc"
    break;

  case 8:
#line 126 "parser.yy"
                  { yylhs.value.as < Node * > () = new Node("BOOLEAN", "", yylineno); }
#line 961 "parser.tab.cc"
    break;

  case 9:
#line 127 "parser.yy"
              { yylhs.value.as < Node * > () = new Node("INT", "", yylineno); }
#line 967 "parser.tab.cc"
    break;

  case 10:
#line 128 "parser.yy"
                     { yylhs.value.as < Node * > () = new Node("typechar", "", yylineno); yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ()); }
#line 973 "parser.tab.cc"
    break;

  case 11:
#line 146 "parser.yy"
                   {
				yylhs.value.as < Node * > () = new Node("MAIN CLASS", "", yylineno);

				Node* methods = new Node("MAIN METHOD", "", yylineno);

				

				yylhs.value.as < Node * > ()->children.push_back(yystack_[16].value.as < Node * > ());


				yylhs.value.as < Node * > ()->children.push_back(methods);
				methods->children.push_back(yystack_[6].value.as < Node * > ());
				methods->children.push_back(yystack_[3].value.as < Node * > ());
				methods->children.push_back(yystack_[2].value.as < Node * > ());
				
		   }
#line 994 "parser.tab.cc"
    break;

  case 12:
#line 177 "parser.yy"
                       { yylhs.value.as < Node * > () = new Node("var declarations", "", yylineno); }
#line 1000 "parser.tab.cc"
    break;

  case 13:
#line 178 "parser.yy"
                                                    { yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > (); }
#line 1006 "parser.tab.cc"
    break;

  case 14:
#line 182 "parser.yy"
                                              {
		
				yylhs.value.as < Node * > () = new Node("var declarations", "", yylineno);
				Node * varDec = new Node("var declaration", "", yylineno);
				varDec->children.push_back(yystack_[2].value.as < Node * > ());
				varDec->children.push_back(yystack_[1].value.as < Node * > ());

				yylhs.value.as < Node * > ()->children.push_back(varDec);
			}
#line 1020 "parser.tab.cc"
    break;

  case 15:
#line 191 "parser.yy"
                                                                               {
				yylhs.value.as < Node * > () = yystack_[3].value.as < Node * > ();
				Node* varDec = new Node("var declaration", "", yylineno);
				varDec->children.push_back(yystack_[2].value.as < Node * > ());
				varDec->children.push_back(yystack_[1].value.as < Node * > ());

				yylhs.value.as < Node * > ()->children.push_back(varDec);
		
			}
#line 1034 "parser.tab.cc"
    break;

  case 16:
#line 203 "parser.yy"
                 { yylhs.value.as < Node * > () = new Node("RETURN SEMI_COLON", "", yylineno); }
#line 1040 "parser.tab.cc"
    break;

  case 17:
#line 205 "parser.yy"
                                                     { 
			yylhs.value.as < Node * > () = new Node("RETURN", "", yylineno);
			yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
		}
#line 1049 "parser.tab.cc"
    break;

  case 18:
#line 214 "parser.yy"
                     {	yylhs.value.as < Node * > () = new Node("methodBody", "", yylineno); }
#line 1055 "parser.tab.cc"
    break;

  case 19:
#line 215 "parser.yy"
                                                      {
				yylhs.value.as < Node * > () = yystack_[3].value.as < Node * > ();
				Node* varDec = new Node("var declaration", "", yylineno);
				varDec->children.push_back(yystack_[2].value.as < Node * > ());
				varDec->children.push_back(yystack_[1].value.as < Node * > ());

				yylhs.value.as < Node * > ()->children.push_back(varDec);
			
			}
#line 1069 "parser.tab.cc"
    break;

  case 20:
#line 227 "parser.yy"
                                     { 
				yylhs.value.as < Node * > () = yystack_[1].value.as < Node * > ();
				Node* varDec = new Node("statement", "", yylineno);
				varDec->children.push_back(yystack_[0].value.as < Node * > ());

				yylhs.value.as < Node * > ()->children.push_back(varDec);
	
			}
#line 1082 "parser.tab.cc"
    break;

  case 21:
#line 239 "parser.yy"
                   { yylhs.value.as < Node * > () = new Node("parameters", "", yylineno);  }
#line 1088 "parser.tab.cc"
    break;

  case 22:
#line 240 "parser.yy"
                           { yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > ();}
#line 1094 "parser.tab.cc"
    break;

  case 23:
#line 243 "parser.yy"
                                { 
				yylhs.value.as < Node * > () = new Node("parameters", "", yylineno);
				Node* params = new Node("parameter", "", yylineno);

				params->children.push_back(yystack_[1].value.as < Node * > ());
				params->children.push_back(yystack_[0].value.as < Node * > ());

				yylhs.value.as < Node * > ()->children.push_back(params);
			}
#line 1108 "parser.tab.cc"
    break;

  case 24:
#line 252 "parser.yy"
                                                     { 
				yylhs.value.as < Node * > () = yystack_[3].value.as < Node * > ();
				Node* params = new Node("parameter", "", yylineno);

				params->children.push_back(yystack_[1].value.as < Node * > ());
				params->children.push_back(yystack_[0].value.as < Node * > ());
				
				yylhs.value.as < Node * > ()->children.push_back(params);

			  }
#line 1123 "parser.tab.cc"
    break;

  case 25:
#line 271 "parser.yy"
                                         { yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > (); }
#line 1129 "parser.tab.cc"
    break;

  case 26:
#line 278 "parser.yy"
                                        {
						yylhs.value.as < Node * > () = new Node("methodDeclarations", "", yylineno);
						Node * methDec = new Node("methodDec", yystack_[7].value.as < Node * > ()->value, yylineno);
						methDec->children.push_back(yystack_[8].value.as < Node * > ());
						methDec->children.push_back(yystack_[7].value.as < Node * > ());
						methDec->children.push_back(yystack_[5].value.as < Node * > ());
						methDec->children.push_back(yystack_[2].value.as < Node * > ());
						methDec->children.push_back(yystack_[1].value.as < Node * > ());

						yylhs.value.as < Node * > ()->children.push_back(methDec);
						


					}
#line 1148 "parser.tab.cc"
    break;

  case 27:
#line 295 "parser.yy"
                                        {
						yylhs.value.as < Node * > () = yystack_[10].value.as < Node * > ();
						Node * methDec = new Node("methodDec", yystack_[7].value.as < Node * > ()->value, yylineno);
						methDec->children.push_back(yystack_[8].value.as < Node * > ());
						methDec->children.push_back(yystack_[7].value.as < Node * > ());
						methDec->children.push_back(yystack_[5].value.as < Node * > ());
						methDec->children.push_back(yystack_[2].value.as < Node * > ());
						methDec->children.push_back(yystack_[1].value.as < Node * > ());

						yylhs.value.as < Node * > ()->children.push_back(methDec);
					}
#line 1164 "parser.tab.cc"
    break;

  case 28:
#line 307 "parser.yy"
                           { yylhs.value.as < Node * > () = new Node("NOOOOOO methodDeclarations", "", yylineno); }
#line 1170 "parser.tab.cc"
    break;

  case 29:
#line 313 "parser.yy"
                                               { /* recursive "*" */
				yylhs.value.as < Node * > () = new Node("LC statement RC", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
			}
#line 1179 "parser.tab.cc"
    break;

  case 30:
#line 318 "parser.yy"
                                                        {/* if without else */
				yylhs.value.as < Node * > () = new Node("IF LP expression RP statement", "", yylineno);
            	yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
            	yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1189 "parser.tab.cc"
    break;

  case 31:
#line 323 "parser.yy"
                                                                       { /* special with "?" ? */
				yylhs.value.as < Node * > () = new Node("IF LP expression RP statement ELSE statement", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[4].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1200 "parser.tab.cc"
    break;

  case 32:
#line 329 "parser.yy"
                                                           { /* ( " else " Statement ) ? */
				yylhs.value.as < Node * > () = new Node("WHILE LP expression RP statement", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1210 "parser.tab.cc"
    break;

  case 33:
#line 334 "parser.yy"
                                                                         {
				yylhs.value.as < Node * > () = new Node("SIMPLE PRINT LOL", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
			}
#line 1219 "parser.tab.cc"
    break;

  case 34:
#line 338 "parser.yy"
                                                                  {
				yylhs.value.as < Node * > () = new Node("SOMETHING ASSIGNED = TO SOMETHING", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[3].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
			}
#line 1229 "parser.tab.cc"
    break;

  case 35:
#line 343 "parser.yy"
                                                                                                        {
				yylhs.value.as < Node * > () = new Node("SOMETHING [ASSIGNED] = TO SOMETHING", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[6].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[4].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
			}
#line 1240 "parser.tab.cc"
    break;

  case 36:
#line 352 "parser.yy"
                     { 	yylhs.value.as < Node * > () = new Node("statements", "", yylineno);}
#line 1246 "parser.tab.cc"
    break;

  case 37:
#line 353 "parser.yy"
                                                 {
				yylhs.value.as < Node * > () = yystack_[1].value.as < Node * > ();				
				Node * reqSTMT = new Node("statement", "", yylineno);
				reqSTMT->children.push_back(yystack_[0].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(reqSTMT);

			}
#line 1258 "parser.tab.cc"
    break;

  case 38:
#line 365 "parser.yy"
                                         {      /*
                                                  Create a subtree that corresponds to the AddExpression
                                                  The root of the subtree is AddExpression
                                                  The childdren of the AddExpression subtree are the left hand side (expression accessed through $1) and right hand side of the expression (expression accessed through $3)
                                                */
				yylhs.value.as < Node * > () = new Node("AddExpression", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
				/* printf("r1 "); */
			}
#line 1273 "parser.tab.cc"
    break;

  case 39:
#line 375 "parser.yy"
                                            {
				yylhs.value.as < Node * > () = new Node("SubExpression", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
				/* printf("r2 "); */
			}
#line 1284 "parser.tab.cc"
    break;

  case 40:
#line 381 "parser.yy"
                                           {
				yylhs.value.as < Node * > () = new Node("MultExpression", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
				/* printf("r3 "); */
			}
#line 1295 "parser.tab.cc"
    break;

  case 41:
#line 387 "parser.yy"
                                        {
				yylhs.value.as < Node * > () = new Node("AND", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1305 "parser.tab.cc"
    break;

  case 42:
#line 392 "parser.yy"
                                                   {
				yylhs.value.as < Node * > () = new Node("OR", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1315 "parser.tab.cc"
    break;

  case 43:
#line 397 "parser.yy"
                                                          {
				yylhs.value.as < Node * > () = new Node("LESS_THAN", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1325 "parser.tab.cc"
    break;

  case 44:
#line 402 "parser.yy"
                                                          {
				yylhs.value.as < Node * > () = new Node("MORE_THAN", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1335 "parser.tab.cc"
    break;

  case 45:
#line 407 "parser.yy"
                                                      {
				yylhs.value.as < Node * > () = new Node("EQUAL", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1345 "parser.tab.cc"
    break;

  case 46:
#line 414 "parser.yy"
                                                                           {
				yylhs.value.as < Node * > () = new Node("expression LEFT_BRACKET expression RIGHT_BRACKET", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[3].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
			}
#line 1355 "parser.tab.cc"
    break;

  case 47:
#line 419 "parser.yy"
                                                {
				yylhs.value.as < Node * > () = new Node("expression DOT LENGTH", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
			}
#line 1364 "parser.tab.cc"
    break;

  case 48:
#line 428 "parser.yy"
                               {
				yylhs.value.as < Node * > () = new Node("TRUE", "True", yylineno);
			}
#line 1372 "parser.tab.cc"
    break;

  case 49:
#line 431 "parser.yy"
                                {
				yylhs.value.as < Node * > () = new Node("FALSE", "False", yylineno);
			}
#line 1380 "parser.tab.cc"
    break;

  case 50:
#line 440 "parser.yy"
                               {
				yylhs.value.as < Node * > () = new Node("THIS", "", yylineno);
			}
#line 1388 "parser.tab.cc"
    break;

  case 51:
#line 443 "parser.yy"
                                                                        {
				yylhs.value.as < Node * > () = new Node("NEW INT LEFT_BRACKET expression RIGHT_BRACKET", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
			}
#line 1397 "parser.tab.cc"
    break;

  case 52:
#line 450 "parser.yy"
                                               { yylhs.value.as < Node * > () = new Node("NEW identifier LP RP", "", yylineno);
									 yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
			}
#line 1405 "parser.tab.cc"
    break;

  case 53:
#line 455 "parser.yy"
                                                      {
				yylhs.value.as < Node * > () = new Node("EXCLAMATION_MARK expression", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
			}
#line 1414 "parser.tab.cc"
    break;

  case 54:
#line 467 "parser.yy"
                              { yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > (); /* printf("r4 ");*/ }
#line 1420 "parser.tab.cc"
    break;

  case 55:
#line 468 "parser.yy"
                                     { /* empty because we have it in root */ yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > ();  }
#line 1426 "parser.tab.cc"
    break;

  case 56:
#line 473 "parser.yy"
                                     {
				yylhs.value.as < Node * > () = new Node("exp DOT ident LP exp COMMA exp RP", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[5].value.as < Node * > ()); /* `new A()` */
        		yylhs.value.as < Node * > ()->children.push_back(yystack_[3].value.as < Node * > ()); /* `a2` */
				yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
				
			}
#line 1438 "parser.tab.cc"
    break;

  case 57:
#line 481 "parser.yy"
                                                {
				yylhs.value.as < Node * > () = new Node("functionCall", "", yylineno);
				yylhs.value.as < Node * > ()->children.push_back(yystack_[6].value.as < Node * > ()); /* `new A()` */
        		yylhs.value.as < Node * > ()->children.push_back(yystack_[4].value.as < Node * > ()); /* `a2` */
				yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
				
			}
#line 1451 "parser.tab.cc"
    break;

  case 58:
#line 495 "parser.yy"
                                           { yylhs.value.as < Node * > () = new Node("DOT identifier LP arguments RP", "", yylineno);
											  yylhs.value.as < Node * > ()->children.push_back(yystack_[3].value.as < Node * > ());
											  yylhs.value.as < Node * > ()->children.push_back(yystack_[1].value.as < Node * > ());
											}
#line 1460 "parser.tab.cc"
    break;

  case 59:
#line 500 "parser.yy"
                                                                  { yylhs.value.as < Node * > () = new Node("DOT identifier LP arguments RP dotExpTest", "", yylineno);
														yylhs.value.as < Node * > ()->children.push_back(yystack_[4].value.as < Node * > ());
														yylhs.value.as < Node * > ()->children.push_back(yystack_[2].value.as < Node * > ());
														yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());
				}
#line 1470 "parser.tab.cc"
    break;

  case 60:
#line 505 "parser.yy"
                                    { yylhs.value.as < Node * > () = new Node("DOT LENGTH", "", yylineno); }
#line 1476 "parser.tab.cc"
    break;

  case 61:
#line 511 "parser.yy"
                  { yylhs.value.as < Node * > () = new Node("empty argument", "", yylineno); }
#line 1482 "parser.tab.cc"
    break;

  case 62:
#line 512 "parser.yy"
                         { yylhs.value.as < Node * > () = yystack_[0].value.as < Node * > (); }
#line 1488 "parser.tab.cc"
    break;

  case 63:
#line 515 "parser.yy"
                          { yylhs.value.as < Node * > () = new Node("argument_list", "", yylineno);  yylhs.value.as < Node * > ()->children.push_back(yystack_[0].value.as < Node * > ());}
#line 1494 "parser.tab.cc"
    break;

  case 64:
#line 516 "parser.yy"
                                              {
				yylhs.value.as < Node * > () = yystack_[2].value.as < Node * > ();
				Node* arg = new Node("argument", "", yylineno);
				arg->children.push_back(yystack_[0].value.as < Node * > ());
				yylhs.value.as < Node * > ()->children.push_back(arg);
			 
			 }
#line 1506 "parser.tab.cc"
    break;

  case 65:
#line 527 "parser.yy"
                       { yylhs.value.as < Node * > () = new Node("identifier", yystack_[0].value.as < std::string > (), yylineno); }
#line 1512 "parser.tab.cc"
    break;

  case 66:
#line 534 "parser.yy"
                                      {  yylhs.value.as < Node * > () = new Node("INT", yystack_[0].value.as < std::string > (), yylineno); /* printf("r5 ");  Here we create a leaf node Int. The value of the leaf node is $1 */}
#line 1518 "parser.tab.cc"
    break;

  case 67:
#line 536 "parser.yy"
                               { yylhs.value.as < Node * > () = yystack_[1].value.as < Node * > (); /* printf("r6 ");  simply return the expression */}
#line 1524 "parser.tab.cc"
    break;


#line 1528 "parser.tab.cc"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yysyntax_error_ (yystack_[0].state, yyla));
      }


    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[+yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yy_error_token_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yy_error_token_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }


      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    std::ptrdiff_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state merging
         (from LALR or IELR) and default reductions corrupt the expected
         token list.  However, the list is correct for canonical LR with
         one exception: it will still contain any token that will not be
         accepted due to an error action in a later state.
    */
    if (!yyla.empty ())
      {
        symbol_number_type yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];

        int yyn = yypact_[+yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yy_error_token_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    std::ptrdiff_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const signed char parser::yypact_ninf_ = -68;

  const signed char parser::yytable_ninf_ = -1;

  const short
  parser::yypact_[] =
  {
     -24,     3,    15,   -68,    17,   -16,   -68,   -16,    45,    18,
     -68,    28,    33,   -68,   -16,    37,    -3,    43,    31,    62,
     -68,   -16,    51,    -3,   -68,    -3,    50,    60,    63,    -3,
      78,    53,   -16,    51,    70,   -68,   -68,   -16,   -68,    -3,
      64,     7,    97,   100,   -16,   -68,   -68,    73,    -3,   103,
      94,   -16,   105,    79,    -3,   109,   -68,   106,    -3,   128,
     -16,   -68,   -16,   114,   133,    95,   -68,   -68,   119,   -68,
     136,   138,   142,   191,   -16,   127,   -68,   -11,    95,   -15,
      44,   191,   191,   191,   191,   -68,   -68,   -68,    -1,   191,
     -68,   143,   -68,   -68,   115,   -68,   191,   191,   134,   -68,
     -11,   -68,   -68,   206,   230,   248,   266,   141,   155,   314,
     191,   191,   191,   191,   191,   191,   191,   191,   191,   -20,
     -68,   -68,   278,   161,   -68,    93,   -15,   125,   -15,   -68,
     191,   160,     1,     1,    20,   337,   326,    32,    32,   348,
     290,   -68,   162,   150,   -68,   152,   146,   -68,   -68,   302,
     -68,   -68,   191,   191,   -68,   -15,   -68,   314,   170,   137,
     179,   -68,   166,   191,   -68,   -17,   -68,   314,   -68,   180,
     191,   185,   166,   -68
  };

  const signed char
  parser::yydefact_[] =
  {
       0,     0,     0,     2,     0,     0,     1,     0,     0,     4,
      65,     0,     0,     3,     0,     0,    12,     0,     0,     9,
       8,     0,    28,    13,    10,    12,     0,     0,     0,     0,
       0,    25,     0,    28,     0,     7,    14,     0,     5,     0,
       0,     0,     0,     0,     0,    15,     6,     0,    21,     0,
       0,     0,     0,    22,    21,     0,    23,     0,     0,     0,
       0,    18,     0,     0,     0,     0,    24,    18,     0,    36,
       0,     0,     0,    16,     0,     0,    20,    10,     0,     0,
       0,     0,     0,     0,     0,    48,    49,    50,     0,     0,
      66,     0,    55,    54,     0,    26,     0,     0,     0,    36,
       0,    29,    37,     0,     0,     0,     0,     0,     0,    53,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      17,    19,     0,     0,    27,     0,     0,     0,     0,    67,
       0,     0,    38,    39,    40,    41,    42,    43,    44,    45,
       0,    47,     0,     0,    34,     0,    30,    33,    32,     0,
      52,    46,    61,     0,    11,     0,    51,    63,     0,    62,
       0,    31,    56,     0,    35,     0,    57,    64,    60,     0,
      61,     0,    58,    59
  };

  const short
  parser::yypgoto_[] =
  {
     -68,   -68,   -68,   -68,   -68,    61,   -68,   169,   -68,   117,
     129,   147,   -68,   -68,   167,   -67,   113,   -19,    30,    34,
     -68,    -5,   -68
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,     2,     3,     8,     9,    21,     4,    22,    23,    75,
      65,    52,    53,    30,    31,    76,    80,   157,   166,   158,
     159,    92,    93
  };

  const unsigned char
  parser::yytable_[] =
  {
      11,   141,    12,    19,   168,   107,   112,    96,    69,    17,
       1,    24,    99,   102,    97,     6,    28,    70,    24,   118,
      24,   119,    71,    72,    24,    10,    20,    40,    10,    10,
      10,    46,    43,     5,    24,   110,   111,   112,   118,    49,
     119,    39,    10,    24,    10,    13,    56,     7,    14,    24,
     118,    15,   119,    24,    91,    64,    16,    66,   102,   146,
      77,   148,   103,   104,   105,   106,    25,    69,   101,    94,
     109,    18,    26,    77,   100,   100,    70,   122,   123,    35,
      27,    71,    72,   108,    32,    29,    34,    39,   161,    10,
      37,   132,   133,   134,   135,   136,   137,   138,   139,   140,
      44,    19,    38,    42,    47,    36,    45,    48,    50,    51,
      54,   149,    55,    57,   142,    51,    69,   145,    69,    62,
     100,   100,    58,   100,    20,    70,    74,    70,    60,    61,
      71,    72,    71,    72,   160,    73,    63,    67,    10,    74,
      10,    68,    79,    81,   167,    82,   110,   111,   112,    83,
     100,    95,   113,   114,   115,   116,   117,   121,   124,   130,
     169,   118,   131,   119,   110,   111,   112,   147,   150,   152,
     113,   114,   115,   116,   117,   153,   154,   155,   162,   118,
     163,   119,   110,   111,   112,   120,   165,   170,   113,   114,
     115,   116,   117,   172,    33,    98,    78,   118,    84,   119,
      41,    59,   173,   144,   171,    85,    86,    87,    88,   110,
     111,   112,   125,    89,   126,   113,   114,   115,   116,   117,
       0,   164,     0,     0,   118,     0,   119,     0,     0,     0,
       0,     0,     0,   110,   111,   112,    10,    90,   127,   113,
     114,   115,   116,   117,     0,     0,     0,     0,   118,     0,
     119,   110,   111,   112,     0,     0,   128,   113,   114,   115,
     116,   117,     0,     0,     0,     0,   118,     0,   119,   110,
     111,   112,     0,     0,   129,   113,   114,   115,   116,   117,
       0,   110,   111,   112,   118,     0,   119,   113,   114,   115,
     116,   117,     0,   110,   111,   112,   118,   143,   119,   113,
     114,   115,   116,   117,     0,   110,   111,   112,   118,   151,
     119,   113,   114,   115,   116,   117,     0,   110,   111,   112,
     118,   156,   119,   113,   114,   115,   116,   117,     0,   110,
     111,   112,   118,     0,   119,   113,     0,   115,   116,   117,
     110,   111,   112,     0,   118,     0,   119,     0,   115,   116,
     117,   110,   111,   112,     0,   118,     0,   119,     0,   115,
     116,     0,     0,     0,     0,     0,   118,     0,   119
  };

  const short
  parser::yycheck_[] =
  {
       5,    21,     7,     6,    21,     6,     5,    18,    23,    14,
      34,    16,    79,    80,    25,     0,    21,    32,    23,    18,
      25,    20,    37,    38,    29,    45,    29,    32,    45,    45,
      45,    24,    37,    30,    39,     3,     4,     5,    18,    44,
      20,    34,    45,    48,    45,     0,    51,    30,    30,    54,
      18,    23,    20,    58,    73,    60,    23,    62,   125,   126,
      65,   128,    81,    82,    83,    84,    23,    23,    24,    74,
      89,    34,    41,    78,    79,    80,    32,    96,    97,    19,
      18,    37,    38,    88,    23,    34,    36,    34,   155,    45,
      29,   110,   111,   112,   113,   114,   115,   116,   117,   118,
      39,     6,    24,    33,     7,    42,    42,     7,    35,    48,
       7,   130,    18,     8,   119,    54,    23,    24,    23,    58,
     125,   126,    43,   128,    29,    32,    65,    32,    19,    23,
      37,    38,    37,    38,   153,    40,     8,    23,    45,    78,
      45,     8,    23,     7,   163,     7,     3,     4,     5,     7,
     155,    24,     9,    10,    11,    12,    13,    42,    24,    18,
     165,    18,     7,    20,     3,     4,     5,    42,     8,     7,
       9,    10,    11,    12,    13,    25,    24,    31,     8,    18,
      43,    20,     3,     4,     5,    42,    20,     7,     9,    10,
      11,    12,    13,     8,    25,    78,    67,    18,     7,    20,
      33,    54,   172,    42,   170,    14,    15,    16,    17,     3,
       4,     5,    99,    22,     8,     9,    10,    11,    12,    13,
      -1,    42,    -1,    -1,    18,    -1,    20,    -1,    -1,    -1,
      -1,    -1,    -1,     3,     4,     5,    45,    46,     8,     9,
      10,    11,    12,    13,    -1,    -1,    -1,    -1,    18,    -1,
      20,     3,     4,     5,    -1,    -1,     8,     9,    10,    11,
      12,    13,    -1,    -1,    -1,    -1,    18,    -1,    20,     3,
       4,     5,    -1,    -1,     8,     9,    10,    11,    12,    13,
      -1,     3,     4,     5,    18,    -1,    20,     9,    10,    11,
      12,    13,    -1,     3,     4,     5,    18,    19,    20,     9,
      10,    11,    12,    13,    -1,     3,     4,     5,    18,    19,
      20,     9,    10,    11,    12,    13,    -1,     3,     4,     5,
      18,    19,    20,     9,    10,    11,    12,    13,    -1,     3,
       4,     5,    18,    -1,    20,     9,    -1,    11,    12,    13,
       3,     4,     5,    -1,    18,    -1,    20,    -1,    11,    12,
      13,     3,     4,     5,    -1,    18,    -1,    20,    -1,    11,
      12,    -1,    -1,    -1,    -1,    -1,    18,    -1,    20
  };

  const signed char
  parser::yystos_[] =
  {
       0,    34,    48,    49,    53,    30,     0,    30,    50,    51,
      45,    68,    68,     0,    30,    23,    23,    68,    34,     6,
      29,    52,    54,    55,    68,    23,    41,    18,    68,    34,
      60,    61,    52,    54,    36,    19,    42,    52,    24,    34,
      68,    61,    33,    68,    52,    42,    24,     7,     7,    68,
      35,    52,    58,    59,     7,    18,    68,     8,    43,    58,
      19,    23,    52,     8,    68,    57,    68,    23,     8,    23,
      32,    37,    38,    40,    52,    56,    62,    68,    57,    23,
      63,     7,     7,     7,     7,    14,    15,    16,    17,    22,
      46,    64,    68,    69,    68,    24,    18,    25,    56,    62,
      68,    24,    62,    64,    64,    64,    64,     6,    68,    64,
       3,     4,     5,     9,    10,    11,    12,    13,    18,    20,
      42,    42,    64,    64,    24,    63,     8,     8,     8,     8,
      18,     7,    64,    64,    64,    64,    64,    64,    64,    64,
      64,    21,    68,    19,    42,    24,    62,    42,    62,    64,
       8,    19,     7,    25,    24,    31,    19,    64,    66,    67,
      64,    62,     8,    43,    42,    20,    65,    64,    21,    68,
       7,    66,     8,    65
  };

  const signed char
  parser::yyr1_[] =
  {
       0,    47,    48,    49,    50,    51,    51,    52,    52,    52,
      52,    53,    54,    54,    55,    55,    56,    56,    57,    57,
      57,    58,    58,    59,    59,    60,    61,    61,    61,    62,
      62,    62,    62,    62,    62,    62,    63,    63,    64,    64,
      64,    64,    64,    64,    64,    64,    64,    64,    64,    64,
      64,    64,    64,    64,    64,    64,    64,    64,    65,    65,
      65,    66,    66,    67,    67,    68,    69,    69
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     1,     3,     1,     6,     7,     3,     1,     1,
       1,    19,     0,     1,     3,     4,     1,     3,     0,     4,
       2,     0,     1,     2,     4,     1,    10,    11,     0,     3,
       5,     7,     5,     5,     4,     7,     0,     2,     3,     3,
       3,     3,     3,     3,     3,     3,     4,     3,     1,     1,
       1,     5,     4,     2,     1,     1,     6,     7,     5,     6,
       2,     0,     1,     1,     3,     1,     1,     3
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"end of file\"", "error", "$undefined", "PLUSOP", "MINUSOP", "MULTOP",
  "INT", "LP", "RP", "AND", "OR", "LESS_THAN", "MORE_THAN", "EQUAL",
  "TRUE", "FALSE", "THIS", "NEW", "LEFT_BRACKET", "RIGHT_BRACKET", "DOT",
  "LENGTH", "EXCLAMATION_MARK", "LEFT_CURLY", "RIGHT_CURLY", "ASSIGN",
  "MORE_THAN_EQUAL", "LESS_THAN_EQUAL", "UNDER_SCORE", "BOOLEAN", "CLASS",
  "ELSE", "IF", "MAIN", "PUBLIC", "STRING", "VOID", "SYSTEM_OUT_PRINTLN",
  "WHILE", "EXTENDS", "RETURN", "STATIC", "SEMI_COLON", "COMMA", "DIVIDE",
  "IDENTIFIER", "INTEGER_LITERAL", "$accept", "root", "goal",
  "classDeclaration", "singleClassDeclaration", "type", "mainClass",
  "varDeclaration", "reqVarDeclaration", "retSTMT", "reqVarOrStmt",
  "parameters", "parameter_list", "methodDeclaration",
  "reqMethodDeclaration", "statement", "reqStatement", "expression",
  "dotExpTest", "arguments", "argument_list", "identifier", "factor", YY_NULLPTR
  };

#if YYDEBUG
  const short
  parser::yyrline_[] =
  {
       0,    72,    72,    75,    83,    90,   103,   125,   126,   127,
     128,   144,   177,   178,   182,   191,   203,   205,   214,   215,
     227,   239,   240,   243,   252,   271,   275,   292,   307,   313,
     318,   323,   329,   334,   338,   343,   352,   353,   365,   375,
     381,   387,   392,   397,   402,   407,   414,   419,   428,   431,
     440,   443,   450,   455,   467,   468,   472,   480,   495,   500,
     505,   511,   512,   515,   516,   527,   534,   536
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


} // yy
#line 2058 "parser.tab.cc"

