public class IllegalClassName {
  public static void main(String[] a){
		System.out.println(new A().Start(10));
    }
}

class 12{ // @error - syntax (illegal class name)

}
