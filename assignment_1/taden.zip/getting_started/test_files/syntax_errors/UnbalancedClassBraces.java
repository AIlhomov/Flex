public class UnbalancedClassBraces {
    public static void main(String[] args) {
        System.out.println(a);
        //@error - syntax (Missing closing brace for the class)